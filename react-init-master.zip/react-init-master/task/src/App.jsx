import React from 'react';

const App = () => {
  return <div>Hello, React!</div>;
};

export default App;
